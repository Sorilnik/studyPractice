package ru.mai.tanks;

public enum TankType {
    MAIN_BATTLE_TANK, MEDIUM_TANK, LIGHT_TANK
}
