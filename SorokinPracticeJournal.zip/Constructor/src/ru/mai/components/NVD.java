package ru.mai.components;

/**
 * Один из компонентов танка.
 */
public enum NVD {
    NVD_ONLY, THERMAL_FIRST_GEN, THERMAL_SECOND_GEN
}
