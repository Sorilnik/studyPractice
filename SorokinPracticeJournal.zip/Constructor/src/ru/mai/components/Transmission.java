package ru.mai.components;

/**
 * Один из компонентов танка
 */
public enum Transmission {
    DUAL_DRIVE, TWIN_TRANSMISSION, CLUTCH_BREAKING, DIFFERENTIAL_BREAKING, CONTROLLED_DIFFERENTIAL, DOUBLE_DIFFERENTIAL
}
