package ru.mai.houses;

/**
 * Дома — это второе семейство продуктов. Оно имеет те же вариации, что и
 * гаражи.
 */
public interface House {
    void paint();
}
