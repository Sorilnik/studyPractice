package ru.mai.document;

/**
 * Реализация .txt документа.
 */
public class TxtDocument implements Document {

    public void open() {
    }

    public void close() {
    }

    public void save() {
    }

    public void revert() {
    }
}
