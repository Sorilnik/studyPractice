package ru.mai.document;

/**
 * Реализация .docx документа
 */
public class DocxDocument implements Document {
    public void open() {

    }

    public void close() {
    }

    public void save() {
    }

    public void revert() {
    }
}